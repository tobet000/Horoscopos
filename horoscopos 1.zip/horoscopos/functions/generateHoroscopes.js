const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

const signos = [
  'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
  'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
];

exports.handler = async () => {
  try {
    const outputFolder = path.join(__dirname, '../../data');
    if (!fs.existsSync(outputFolder)) {
      fs.mkdirSync(outputFolder, { recursive: true });
    }

    for (const signo of signos) {
      const res = await fetch(`https://aztro.sameerkumar.website/?sign=${signo}&day=today`, {
        method: 'POST'
      });
      const data = await res.json();

      const horoscopo = {
        signo,
        horoscopo: data.description,
        fecha: new Date().toISOString()
      };

      fs.writeFileSync(
        path.join(outputFolder, `${signo}.json`),
        JSON.stringify(horoscopo, null, 2)
      );
    }

    return {
      statusCode: 200,
      body: '♻️ Horóscopos generados con éxito'
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: `Error generando horóscopos: ${err.message}`
    };
  }
};